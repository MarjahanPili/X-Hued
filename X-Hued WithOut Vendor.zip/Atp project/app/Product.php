<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
	//protected $table = 'my_flights';
	//protected $primaryKey = 'my_flights';
	
    public $timestamps = false;
}
