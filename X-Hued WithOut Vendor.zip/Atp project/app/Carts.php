<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carts extends Model
{
    //protected $table = 'my_flights';
	//protected $primaryKey = 'cartId';
	
    public $timestamps = false;
}
