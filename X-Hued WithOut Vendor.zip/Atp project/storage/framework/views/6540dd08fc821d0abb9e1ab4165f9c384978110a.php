<html>

	<head>
		<link rel="stylesheet" href="css/bootstrap.css">
		<script type="text/javascript" src="/assets/essence/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="/assets/essence/style.css">
		<script type="text/javascript" src="/assets/mk/jquery-3.3.1.js"></script>
		<script type="text/javascript" src="js/jquery.printPage.js"></script>
	</head>

	<body>

	    <div class="container">
	      	<div class="col-md-12">

	         	<?php echo $__env->yieldContent('content'); ?>

	      	</div>
	    </div>

	</body>
</html>